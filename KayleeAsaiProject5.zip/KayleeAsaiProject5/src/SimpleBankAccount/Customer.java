package SimpleBankAccount;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kayleeasai
 */

public class Customer {
    String FirstName;
    String LastName;
    private String SSN;
    
    private static String deleteCharAt(String strValue, int index) {
	return strValue.substring(0, index) + strValue.substring(index + 1);
	}
    
    Customer(String FirstName, String LastName, String SSN){
        this.FirstName=FirstName;
        this.LastName=LastName;
        if (SSN.length()==11){
            char dash='-';
            if (SSN.charAt(3)==dash && SSN.charAt(6)==dash){
                String newSSN=deleteCharAt(SSN, 3);
                String finalSSN=deleteCharAt(newSSN, 5);
                if(finalSSN.matches("[0-9]+") && finalSSN.length() > 2) {
                }
                else{
                    System.out.println(SSN+" is not a valid SSN."); 
                }
            }
            else{
                System.out.println(SSN+" is not a valid SSN.");   
            }
        }
        else{
            System.out.println(SSN+" is not a valid SSN."); 
        }
    }
    
}
