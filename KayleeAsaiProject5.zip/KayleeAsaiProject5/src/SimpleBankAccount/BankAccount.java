package SimpleBankAccount;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kayleeasai
 */
public class BankAccount extends Customer{
    
    String accNum;
    float balance;
    float deposit;
    
    BankAccount(String FirstName, String LastName, String SSN, float balance){
        super(FirstName, LastName, SSN);
        accNum="";
        this.balance=balance;
        int i=0;
        while (i<10){
            accNum=accNum+(int)(Math.random()*10);
            i++;
        }
        System.out.println("Successfully created account for "+FirstName+" "+LastName+". Account Number: "+accNum); 
        System.out.println("The balance for this account is: "+balance); 
    }     
    public void deposit(float D){
        balance=balance+D;
        System.out.println(FirstName+" "+LastName+" deposited $"+D+". Current Balance is: $"+balance); 
    }
    public void withdraw(float WD){
        if (balance>WD){
            balance=balance-WD;
            System.out.println(FirstName+" "+LastName+" withdrew $"+WD+". Current Balance is: $"+balance); 
        }
        else{
            System.out.println("Unable to withdraw $"+WD+" for "+FirstName+" "+LastName+" due to insufficient funds.");
        } 
    }
    public void applyInterest(){
        System.out.println("Standard Bank account does not apply an interest."); 
        System.out.println(FirstName+" "+LastName+", Balance $"+balance); 
    }
    public void checkBalance(){
        System.out.println(FirstName+" "+LastName+", Balance $"+balance); 
    } 
}

