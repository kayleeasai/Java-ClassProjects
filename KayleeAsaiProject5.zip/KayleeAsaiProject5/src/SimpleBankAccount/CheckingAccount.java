package SimpleBankAccount;


import SimpleBankAccount.BankAccount;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kayleeasai
 */
public class CheckingAccount extends BankAccount{
    
    public CheckingAccount(String FirstName, String LastName, String SSN, float balance) {
        super(FirstName, LastName, SSN, balance);
    }
    
    @Override
    public void applyInterest(){
        if (balance>10000){
            float num=balance-10000f;
            balance=balance+(num*.02f);  
        }
        else{
            System.out.println("Insufficient funds to apply interest."); 
        }
        
    }
    
}
