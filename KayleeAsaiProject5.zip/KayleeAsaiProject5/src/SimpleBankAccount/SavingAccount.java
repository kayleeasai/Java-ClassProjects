package SimpleBankAccount;


import SimpleBankAccount.BankAccount;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kayleeasai
 */
public class SavingAccount extends BankAccount{
    
    public SavingAccount(String FirstName, String LastName, String SSN, float balance) {
        super(FirstName, LastName, SSN, balance);
    }

    @Override
    public void applyInterest(){
        balance=balance*1.05f;
    }
    
}
